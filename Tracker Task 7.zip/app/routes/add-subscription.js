import Route from '@ember/routing/route';

export default class AddSubscriptionRoute extends Route {}
