export default function reverseArray(positionalA) {
  return positionalA.slice().reverse();
}
