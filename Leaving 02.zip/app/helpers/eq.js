export default function eq(val1, val2) {
  if( val1 == val2) {
    return true
  } else {
    return false
  }
}
