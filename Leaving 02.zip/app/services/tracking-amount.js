import Service from '@ember/service';

export default class TrackingAmountService extends Service {}
