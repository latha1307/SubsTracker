import Route from '@ember/routing/route';

export default class SubscriptionRoute extends Route {}
