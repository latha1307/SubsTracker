export default function inc(val) {
  return val + 1;
}
