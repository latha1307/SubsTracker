
export const walletHistory=[
    {
        id: 1,
        amount: 199,
        method: 'debit',
        date: '12-04-2025',
        statement: "Paid for Youtube"
    },
    {
        id: 2,
        amount: 500,
        method: 'credit',
        date: '12-04-2025',
        statement: "Added from Bank"
    },
    {
        id: 3,
        amount: 500,
        method: 'credit',
        date: '12-04-2025',
        statement: "Paid for Youtube"
    },
    {
        id: 4,
        amount: 500,
        method: 'debit',
        date: '12-04-2025',
        statement: "Paid for Youtube"
    },
    {
        id: 5,
        amount: 500,
        method: 'debit',
        date: '12-04-2025',
        statement: "Paid for Youtube"
    },
    {
        id: 6,
        amount: 500,
        method: 'credit',
        date: '12-04-2025',
        statement: "Paid for Youtube"
    },
    {
        id: 7,
        amount: 500,
        method: 'debit',
        date: '12-04-2025',
        statement: "Paid for Youtube"
    },
    {
        id: 8,
        amount: 500,
        method: 'debit',
        date: '12-04-2025',
        statement: "Paid for Youtube"
    },
    {
        id: 9,
        amount: 500,
        method: 'debit',
        date: '12-04-2025',
        statement: "Paid for Youtube"
    },
    {
        id: 10,
        amount: 500,
        method: 'credit',
        date: '12-04-2025',
        statement: "Paid for Youtube"
    },
];