import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';

export default class ViewSubscription extends Component {
    @tracked subName = '';
    @tracked plan = '';
    @tracked billCycle = '';
    @tracked amount = '';
    @tracked category = '';
    @tracked pay = '';
    @tracked viewSub = null;

    constructor() {
        super(...arguments);
        this.viewSub = this.args.viewSub;
        if (this.viewSub) {
            this.subName= this.viewSub.subName
        }
        console.log(this.viewSub)
    }
}
