'use strict';

module.exports = {
  extends: ['stylelint-config-standard'],
};
